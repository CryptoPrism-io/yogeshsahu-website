#!/usr/bin/env bash
# Verify your Plausible integration. Replace YOUR-DOMAIN.

# 1. Tracker loads — expect 200
curl -sI https://plausible.yogeshsahu.xyz/js/script.outbound-links.js

# 2. Site accepts events — expect 202 (400 = domain not registered yet)
curl -s -o /dev/null -w "%{http_code}\n" -X POST "https://plausible.yogeshsahu.xyz/api/event" \
  -H "Content-Type: text/plain" -H "Origin: https://YOUR-DOMAIN" \
  --data-binary '{"domain":"YOUR-DOMAIN","name":"pageview","url":"https://YOUR-DOMAIN/","referrer":""}'

# 3. Trigger an action on the live site, confirm it in Realtime within seconds.
