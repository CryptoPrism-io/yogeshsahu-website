---
name: plausible-analytics
description: Develop and manage Plausible analytics for <SITE_DOMAIN> — install/verify the cookieless tracker, add custom events, register Goals. Use when adding or debugging tracking, events, or goals in this repo.
---

# Plausible Analytics — <SITE_DOMAIN>

## Fixed facts
- Analytics host: `https://plausible.yogeshsahu.xyz` (self-hosted Plausible CE)
- Tracker: `/js/script.outbound-links.js` (auto: pageviews, outbound clicks, file downloads, scroll, engagement)
- `data-domain` is a label, not a URL — one host serves every product
- This site: `<SITE_DOMAIN>` (already registered — do not re-register)
- Unregistered domain: owner registers FIRST (Plausible UI → Sites → Add a website); events are dropped otherwise.

## 1. Install/verify tracker
Entry point by framework:
- Next.js (App Router): `src/app/layout.tsx` — add via `next/script` (`afterInteractive`)
- Next.js (Pages Router): `pages/_app.tsx` or `pages/_document.tsx`
- Vite/React: `index.html` or `main.tsx`
- Firebase static hosting: `public/index.html`
- Plain HTML: `<head>` of root `index.html`

Tag:
```html
<script defer data-domain="<SITE_DOMAIN>" data-outbound-links data-file-downloads
  src="https://plausible.yogeshsahu.xyz/js/script.outbound-links.js"></script>
```
CSP: allow the host in `script-src` AND `connect-src` (event POST is cross-origin).

## 2. trackEvent helper (if none)
```ts
declare global { interface Window { plausible?: (event: string, opts?: { props?: Record<string, string | number> }) => void } }
export function trackEvent(name: string, props: Record<string, string | number> = {}): void {
  if (typeof window === "undefined" || typeof window.plausible !== "function") return;
  window.plausible(name, { props });
}
```
Server components: mounted client wrapper fires once ~400ms after mount.

## 3. Instrument key interactions
snake_case names + `source` prop when multiple triggers. Conversion: CTA clicks, signup/login, purchase/checkout, form submit, plan click. Engagement: feature open, search, filter, nav. Content: read, open, click. Comment each: `// event: <name>`.

## 4. Goals (conversion events only)
```sql
INSERT INTO goals (event_name, inserted_at, updated_at, site_id, display_name, scroll_threshold)
SELECT '<event_name>', now(), now(), id, '<Display Name>', -1 FROM sites WHERE domain = '<SITE_DOMAIN>'
ON CONFLICT DO NOTHING;
```
Run on the Plausible VM + restart the plausible container (owner-side).

## 5. Verify
1. `curl -sI https://plausible.yogeshsahu.xyz/js/script.outbound-links.js` → 200
2. POST `https://plausible.yogeshsahu.xyz/api/event` with `"domain":"<SITE_DOMAIN>"` → **202**
3. Build/lint; hard-refresh the live site; confirm the event in Realtime.

## Hard rules
- No dummy/synthetic events — real interactions only; ask first if unsure.
- Minimal diff, follow repo conventions, env vars over hardcoding.
- Never commit secrets (tracker host is public; API keys are not).
- Register BEFORE tracker for unregistered domains.
