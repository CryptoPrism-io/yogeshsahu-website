-- Register a conversion Goal per event, for YOUR site only. Replace YOUR-DOMAIN and signup_click.
INSERT INTO goals (event_name, inserted_at, updated_at, site_id, display_name, scroll_threshold)
SELECT 'signup_click', now(), now(), id, 'Signup Click', -1
FROM sites WHERE domain = 'YOUR-DOMAIN'
ON CONFLICT DO NOTHING;
